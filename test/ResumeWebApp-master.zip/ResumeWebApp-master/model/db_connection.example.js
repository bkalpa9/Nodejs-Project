exports.config = {
    user: '',
    password: '',
    host: '',
    database: ''
};
